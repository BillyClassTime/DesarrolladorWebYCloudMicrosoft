# Desinstalar el WCFDataServices

La versión WCF DataService 5.0 deberá estar en la carpeta: 

```powershell
 C:\ProgramData\Package Cache\{ad60454d-9edf-4100-8342-06830732be63}
```

Desde una linea de comandos de MSDOS y en esa carpeta desinstalarlo así:

```
WcfDataServices.exe /uninstall
```







	

